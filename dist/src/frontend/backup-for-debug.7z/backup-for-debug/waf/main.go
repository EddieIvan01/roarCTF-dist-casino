// simple WAF
// bypass me if you can
package main

import (
	"bytes"
	"io"
	"log"
	"net"
	"os"
	"strings"
	"sync"
)

var WAFWORD []string = []string{
	"select",
	"substr",
	"union",
	"and",
	"or",
	"char",
	"order",
	"between",
	"length",
	"if",
	"into",
	"limit",
	"regexp",
    "\\u",
}

func forward(pool TcpPool, client net.Conn, serverC *C) {
	defer client.Close()
	defer pool.Put(serverC)

	server := serverC.conn
	var wg sync.WaitGroup
	wg.Add(2)

	go func() {
		defer wg.Done()
		io.Copy(client, server)
	}()
	go func() {
		defer wg.Done()
		ok := tcpWaf(server, client)
		if !ok {
			client.Close()
			return
		}
	}()

	wg.Wait()
}

func tcpWaf(server net.Conn, client net.Conn) bool {
	defer func() {
		recover()
	}()
	buf := make([]byte, 4*1024)

	for {
		nr, er := client.Read(buf)
		dataS := bytes.Split(buf[:nr], []byte{13, 10, 13, 10})

		// get the request body
		// split by CRLFCRLF
		data := bytes.Join(dataS[1:], []byte(""))

		for _, word := range WAFWORD {
			if strings.Contains(strings.ToLower(string(data)), word) {
				client.Write([]byte("HTTP/1.1 200\r\nServer: iWAF/0.0.1\r\n\r\nintercepted\r\n\r\n"))
				return false
			}
		}
		if nr > 0 {
			nw, ew := server.Write(buf[0:nr])
			if ew != nil {
				break
			}
			if nr != nw {
				break
			}
		}
		if er != nil {
			break
		}
	}
	return true
}

func main() {
	l := os.Args[1]
	dst := os.Args[2]
	pool := NewPool(dst)
	server, _ := net.Listen("tcp", "0.0.0.0:"+l)
	defer server.Close()
	for {
		clientConn, _ := server.Accept()
		serverConn, err := pool.Get()
		if err != nil {
			log.Println(err.Error())
		}
		go forward(pool, clientConn, serverConn)
	}
}
