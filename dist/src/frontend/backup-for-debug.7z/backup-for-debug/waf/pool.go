// simple HTTP connection pool
package main

import (
	"log"
	"net"
	"time"
)

var MAX_WORKER = 100
var TIMEOUT = time.Second * 30

type TcpPool struct {
	dst     string
	workers chan *C
}

type C struct {
	conn  net.Conn
	ctime time.Time
}

func (p TcpPool) generate() error {
	tcpAddr, _ := net.ResolveTCPAddr("tcp", p.dst)
	conn, err := net.DialTCP("tcp", nil, tcpAddr)
	conn.SetLinger(0)
	if err != nil {
		return err
	}

	p.workers <- &C{
		conn,
		time.Now(),
	}
	return nil
}

func (c C) close() {
	c.conn.Close()
}

func (c C) isTimeout() bool {
	return c.ctime.Add(TIMEOUT).Before(time.Now())
}

func NewPool(dst string) TcpPool {
	p := TcpPool{
		dst,
		make(chan *C, MAX_WORKER),
	}

	go func() {
		for {
			if len(p.workers) > MAX_WORKER {
				time.Sleep(TIMEOUT / 10)
			}
			err := p.generate()
			if err != nil {
				log.Println(err.Error())
			}
		}
	}()

	return p
}

func (p TcpPool) Get() (*C, error) {
	var c *C
	for {
		c = <-p.workers
		if c == nil || c.isTimeout() {
			c.close()
			continue
		}
		break
	}
	return c, nil
}

func (p TcpPool) Put(c *C) {
	select {
	case p.workers <- c:
		return
	default:
		c.close()
	}
}
