import Vue from 'vue'
import App from './App.vue'
import Router from 'vue-router'

import Login from './components/Login.vue'
import Register from './components/Register.vue'
import Index from './components/Index.vue'
import Profile from './components/Profile.vue'

import './assets/js/jquery.min.js'
import './assets/js/popper.min.js'
import './assets/css/bootstrap.min.css'

Vue.use(Router)

const router =  new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index,
    },
    {
      path: '/register',
      name: 'register',
      component: Register,
    },
    {
      path: '/login',
      name: 'login',
      component: Login,
    },
    {
      path: '/profile',
      name: 'profile',
      component: Profile,
    }
  ]
})

new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
