<template>
  <div id="navbar">
    <transition name="slide">
    </transition>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <router-link :to="{name: 'index'}" class="navbar-brand">Casino</router-link>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <router-link :to="{name: 'index'}" class="nav-link">
              Index
              <span class="sr-only">(current)</span>
            </router-link>
          </li>
          <li class="nav-item" v-if="login">
            <router-link :to="{name: 'profile'}" class="nav-link">Profile</router-link>
          </li>
          <li class="nav-item" v-if="!login">
            <router-link :to="{name: 'register'}" class="nav-link">Register</router-link>
          </li>
          <li class="nav-item" v-if="!login">
            <router-link :to="{name: 'login'}" class="nav-link">Login</router-link>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</template>

<script>
export default {
  name: "NavBar",
  data() {
    var login = document.cookie.indexOf('casino=') != -1
    return {
      login: login,
    }
  }
}
</script>

<style scoped>
h1,
h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
