<template>
  <div id="login">
    <NavBar></NavBar>
    <br />
    <router-view></router-view>
    <div class="container col-md-6">
      <form>
        <div class="form-group">
          <label for="uname">Username:</label>
          <input v-model="uname" type="input" class="form-control" id="uname" />
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input v-model="pwd" type="password" class="form-control" id="pwd" />
        </div>
        <button type="submit" @click="login" class="btn btn-primary">Login</button>
      </form>
    </div>
  </div>
</template>

<script>
import NavBar from "./NavBar.vue";
import { auth } from "../config";

export default {
  name: "Login",

  methods: {
    login: function() {
      var url = auth + "/login";
      var data = {
        uname: this.uname,
        pwd: this.pwd
      };
      fetch(url, {
        method: "POST",
        credentials: "include",
        body: JSON.stringify(data)
      })
        .then(resp => resp.json())
        .then(respJSON => {
          if (respJSON["status"] == 0) {
            alert("login success");
            location.href = "#/";
            location.reload();
          } else {
            alert(respJSON["msg"]);
            location.reload();
          }
        });
      window.sessionStorage.pwd = "";
    }
  },

  data() {
    return {
      uname: "",
      pwd: ""
    };
  }
};
</script>

<style>
</style>
