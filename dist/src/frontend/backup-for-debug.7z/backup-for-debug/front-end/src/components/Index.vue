<template>
  <div id="index">
    <NavBar></NavBar>
    <br />
    <router-view></router-view>
    <div class="container col-md-6">
      <div class="jumbotron">
        <h2>Welcome to my casino!</h2>
        <p>
          You can get flag by following two ways:
          <br />1. winning the gambling
          <br />2. having more than $999,999 money
          <br />GOOD LUCK
          <br />
          <br />of course, if you transfer $999,999 to the developer, he'll give you FLAG right away:)
          <br /><br />
          <button @click="change" type="button" class="btn btn-info">Show the pay QR code</button>
          <br /><br />
          <img v-if="show"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAGGCAIAAABOmCuqAAAgAElEQVR4nO2de3BU153nf+feVnfr1egBkhBCSLwMGINjiOMhNngc4uDdxOXx7HjtbC3jzWZI2ZXyepOMS8W6SG2qhiUZT+bl8biyGU8V40ow453xMI7tMF4GHIZ4HSCYKIANRLIQIAnRklqvft372z/Ovbev3lLrdp/u5vspW7Ra9zzu7fvt3zm/3/mdK5iZAADq0FR3AIBbHYgQAMVAhAAoBiIEQDEQIQCKgQgBUAxECIBiIEIAFAMRAqAYiBAAxUCEACgGIgRAMRAhAIqBCAFQDEQIgGJ8aZQRQnjeD6/IRHrkVOeb6VTMLFznuZ6CqksxYweUM58rMGdLmLNXQZLj3QPzIZc/3Pn0rQCHo7n8UYG0yf2PNe0eFqAIAcgvClOEuf+tCYBDYYoQACWk9+0PEQKgmHRCFNNTAI57ALKJlyLMTrDIaSVtNWY62DXXjnl43aaqaq5dyvQ3nbcfQTb3zs3ElfFsOJr9TYSxbTGgrN8GmWgOc0IAFAMRAjA3PDeGECHIYwpjSgIRAqAYiBAAxUCEACjG+2D9OOYfV0Gu2jgKYCKUnVOYzweazYucB5YwX7QBcop53jbZvOvyQIQAKCFrOoQIAVAMRAiAYiBCABQDEQKgGIgQAMVkPE6YR3gVGvJqM8808KqqTOclFkCo00NgCQFQDEQIgGIgQgAUAxECoBiIEADFQIQAKAYiBEAxiBPOzFyDXTmYe4W4XC4DSwiAYiBCABQDEQKgGIgQAMXkgQjhVACFTcZFOE8JQYFAFVm797IRooCQQPbJo7sOccIUmU7Gy3S7WSCP7uw8Ig/mhAAUNhAhAIqBCAFQDEQI8pg8mk5Pg2cizP7lKIwPAOQdnt94XlrCrKlCCAEFAkmW74RMNOdxiALaANkn3+86xAlT5Npmm2n0Z65F8uX4wgaOGQAUAxEC4BnpWfLCFOGtOaoBeUphihCAPGLOIsx9I5P7PQQFSdo3XjqWMJfv8lzuG5gPOf7Jzqd7aYYonCZzJEST458Q8ARmzpH7bRzzvP0Ebt8ZKYCg1lzvXa9OTVW7+QUcMwAoBiIEQDEQIQCKgQgBUAxECIBiIEIAFAMRAqAYiBAAxWQ8WO9VpDs3l0pMilfJwWl8NJl+nqmqIP40Tau6MTwUDiwhAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKGbOccJMR5a8qj+NHXK96tJc21UYAs305rwe5kNnOrVa4f7FsIQAKAYiBEAxECEAioEIAVAMRAiAYiBCABQDEQKgmDnvwJ1rYZk0wjWZjvt5RRYeEjpXMh3SVBjdVbjvMCwhAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKGbOccJM72w5FR6GcbzKEMu146cpMtfjFeYNzpVM35BZyPaEJQRAMRAhAIqBCAFQDEQIgGIgQgAUAxECoBiIMJ/QNC0UCsnX41zw8tf6+vpQKKRp+FjzCc/yCXPtOYRpBNMyHVmaZ9AsGAw2NjZu2bJlmmOeffbZc+fOnThxoqOjIxqNzlinqvzDqdr18FObCoV5g1Ph2UNCIcL5dGlSioqKqqqqmpqa1q9ff//992/YsKGxsdHv95eWlsra3B2Tv8ZisWQyGY/HOzo6zp49e/To0dbW1vb29nA4nEwmZ9+lTEeoc3Dz37m2OxXpnBpEOGOR7ItQHrlnz5577rln8+bNVVVVPp9PCCGV5sjPqdD9J+dXIkomk+Fw+OTJk++///5bb7119uzZcVKECNNudyogwlm1m8sidNu3WCzm9/vHdYOZmSlpssFsmsTERCRIaBrpQvg0IQSNE6q0kD09PR988MH+/fuPHz/e399vmuY0XYIIZ2x3KiDCWbWbyyKceLxs3TR5IJq82h/risS6IvHrkVgkaozGjYRhCiF8mij266GgvjgUqAv560KBJRWBBUGf03FHlsPDw4cPHz5w4MBbb701NDQEEabd7lRAhLNqNzdFOG6OJ9+JG9w3nGi9PnzsUt9H3cNX+2PDcSOWNA2TTSYiYiJBRIIEkSDSNeHXRVnAt6QicFtt6baVlesXl1aWFvl14R6yhsPhQ4cOvfDCC62trZOeHUQ4Y7tTARHOqt2cEqF7Ludu7uZw/FTH4LGLfccu9XVF4obJuhxqEpEQsi5BZP0g+1fXkFUWqQv5t62s3LaqclNjeXWpn1wG9pNPPlm2bFlGT3kqIMIxTUCEMxbJmgjli9GEefRi39+f7v7w6mAkZjCTJuw+MEsF0rRdctdmMglBoYC+cUn5791Ve/+qyuKiVBRxrhtJegVEOKaJXBNhDpKJRyb6/f4HHnhg3759GzdudAaig9HkibaBH564eqojIoTQNSIWJJiY5BFMLGzTRySc0aiUJTOPaYOJSIqWmNhkIqa7Gsu/umXJluYF5UGf09uzZ8+2tLQcOXIkHo9PfwpTkYNfnXNF4fMJIcKZyYQIH3vssb17965YscI5+Hok9uKxzsPnb/aNJjTrUMGCBQlHa0SO7phImkSSakyNTuVIVZB9gK1SIiYymSuLix5cW/31bQ2LQwGnY21tbS0tLQcPHpz+FKYCIpxPfyDCmfFWhMFgcOfOnXv37q2urpbvRxPm2+d6X3rvStvNqCU+e8zpMn0TWiG2VSd/WIKlMQZz8r6ZzCsWljx1X8ND6xYGfMLx1uzevXv//v3RaBQinLF+iDCreCvCXbt2fec736mtrZVvRkaTPz7V9dLPrgzFTE1IP6ewxppsD0InKGriTNIdG7QOkZUxS4sq/TmOqTSZygLa0/ctfWJTXXlQl2V6enr27Nnzgx/8ACKcsX6IMKt4JcJAIPDII4+89NJLVVVVUjM9g4kX/m/7T1p7EyYLEi5Pp2yYxsrPHomaTDIib7LjpmHHftJUVtCu3BY2M/s08aU7Fn3zgWW1IWtVwM2bN59++unXXnttTqcMEc6nPxDhzHglwoceeuill15qamqSCuyKxPcdbv/n1hu69H5ahWyRWINNJhZMlsdF2rr7VlQsWRAY10Y0Yf7bb/pvDMWlFqVHhy1ppoKQbI9f5f9MbJj8pfWLWh5sqgv5Zcfa29ubm5szeomm4tYU4ZyzKEDa7Nu3r7m5mZmlDdz3L+1vn+vVNWFbMCIiEsK2ZVKNclqYcrxoRI9vqr13RYV1vF2udzjR2R/tGYprRPZglqygoWtwK6sSlhRJ+mDfPtdLgnY/2FxTXiSEaGpqoskWD4AMARFmDycaERlN/smRT9781Q1Ns1yXLATZxksIYfs3WU4S5R+coalPE0GfNk4h/phhvXL8pFaV0uKRrIKIhZBvWPXLaeM//+pGkS727FgeKvZBe1lmztmfYgp4CqY63qsT8LD+uZ7aVExVv/xTLGm+drrrzV/1SgUKsmKAIjUFlNqTv9lTxQln5G7O8tBYp2GdzLjJobCqEM5ru0VBRLom3mq9+drprljSlNX29/d/7WtfKyoqmuqyzOYSTXMp5nT8NMyme7O5MTzs0lxBCnY2YNdS7J+e733xvSsJ05T3z1iHJrP0scgS1n9shd1dOPeT+6c9qWRZilm+ZJaas4Xqvq9k1SQECZEwzb96r/On53tl5RUVFc8///yaNWsyeWEAEUSYBZxvU2a+Hon91XudQzHTZaQch4wd5BOCrdUwTJZZHP+F7K7TeVM4/wpiSnlbScpRjD9eSluqXUp5MGa8eKyzayAmD2hoaPjGN75RUlIy/4sApgEizCDOHS8t1WDM+MujVy7fGLXjgcTsxNdZWIvOLE+McAaOUlJsC8plEh0jyuy2lczEwq5XWPbP0nFqRMYsLBvJlpOGSBN0+cbInx/tiESt3N+HH374i1/8IjatySi4uBlEuMLozPzztoHDF24KYU/whPWnpMFxw4wbZixhxBJGPGnGDTMu30yasYRhvzbiSTOeZMO0BqxsOzCFEMRkmizLJpJsVWVwLGkmDDOWNBIGyxpkEwmTWWpUEFujWSYSmib+5UL4520DstqqqqrHH3+8oqJiuvME82POccKpprZT1TPX4+eKh/VntKsjcWPn37X+8sqgZhkja/hpGLx1VcXnVsslbE5Dk8To5WshxNaVFUsrgzw2hDASN352uf/GYNw+mO162PUzVeHVgejB012RqJGqxF5OYzJ/amn5/v+8vrhIE0IMDw9/+ctfPnTo0DRnl4VPfxqfypzIwRsPIYqMI9Xy3qW+Ux2DTmTBWhlKwiReVhXcunKBOevPrqq0aOKbfp+2cUlZNGHOpgZBdKHb9w9nNCKDrWGwtVSViDQhTncMvnepb8e6hURUUlKyc+fOt956a9KtosD8gQgzjhDi5nD84OluzTKBgu1wARH5NPHPv+o9drGPeIzNGme5yH6TiPY+vHLL8vHjw/6RxB+903b22pDmqoFcBcd9b8cNHhhNWn+2V7FZc1ISQtBrp7o/vSxUVVIkhLj77rs3bNhw+vRpjy8NIKICEKGHkRzPg0LOhPD0lcEznYO6RmxNv2T6nyXFSDQZiSYnEw45wXS7QtI1EUua7g5L22ow9Q4nrg7E7DChcKJcwnnLdYq22px0KKtLsqiu0YdXB09fGdx+WxUzL1269NSpU9OcaRYmKaqGkV4Ng6cBjpmM4JZH3OBjF/siUcN6w06TT2UtOdFzIYSwf5L1C42JR6d06oQKnZiyGPM+CyE0TWiaE5qX9jAVs7bbt1shx0dDRCISM45e7Isbeb/0N/fJe0uYmzjyIKK+4cTRi31yyRi5Em1Tvk0iImZBxGQyMZvO6NEeiKZiibpgctlY4dqfxmQyTDZT5tQpJSXK9upt0jV7UZz9trVoPNUWM9Oxi319WxO1IT9PkioFPAMizCxCiNbrw9cjMU1aI/fIkqxV1tZqMuallcGN9eWT1TJGvzXlfrck5M+gT7t3RUVdKJDyvPLklRgm//JKpGswLuxVqzwmAUr+LjTB1yOx1uvDTpYTFJghIMJMIQ2UafKxS32Gybou7MQIIkqtBRW2UyRp8Kcby//o4VUzzhCkbMZJIhTUn97aMF54k9E1GH/qwPmuwTgzyZXhlsOW5HYabHlnSBimeexS3wOrK6G+jAIRZgRHJP2jiQvdw7qmObZm7CjU+lcIYblFmDRduCsZszBt7BB0nC/BXemY9105+ETU0Re9NhBzFs6kFtDJHTKku0YQEeua9lH38EA0WVkySVAEeAVE6DHO7S7VcrU/dq0/plmL1ORKaWf/GDlCdDKYqHsw8f4nA75UtoOs0VX7pG/SBO0xlQX1VYtK5J6/Tn+Y2WRqvTY0FDOsFXPWAJntNTx2TjGzEEITfLU/drU/VlHsIwxHMwZE6D1uS9UViQ3FklJ4lu5S4z9rsSgRCUE6aR+0D5zuiJBrqwr5k+2dDwUJTZAd1rdmckys2QEP+dMw+e5lC773O6sWlVm7/Toe0WjcONURiSdNXZdbIdo72qQcR2RpkpmIhmLJrkjs9sWldpPwzXiPZyKc62cz1+M9DONkNCLU0NDwzDPPPPPMM36/n5m6InHLy28P/8hOO0rtICrvfcFJk5KWwib2cA7vM1NFia+4SHcnW8ivhvBI4kznoHAWr8qG7V6JlCfVMtBxg7sicWbSNBGLxQKBwJx0mOm7gjIQ3c1y/QRL6DklJSVNTU0y7SBp8vVITK63JjlAJcv7aJk/KwQhWK6jTlVjj0jlH1wqtmPr9jGu0aS1y68gQbS6prTEPz77Xgjxi08i3YNxXRNO5qJVtZPP4aQc2q7U65FY0mS/JpBLkSEgQo8JBoP19fXyfjWYI1HDZNLGpN46u2mTtd+S9KOyba+INGEl9bqj83L0aq1ucZA+V/doksmva3c2lAvXt7i1bCBpHr0YZrdrVnaH7O8I5w+uOOdg1DCYmVnTtOxkmt9qQIQeEwwGq6qqiEgIYZo0GjfYFps9BrU9nIKJyWSzuEjftqryroZyEhRLmoNRo3802T+S6BtJhkfikagxEjdGEmbSYE2wpglhr7jm1GYxJIS1WbfJvLau9FMN5TR2dMfMv74+9EF7pMjSkjSvts6FbXJFylEkBJlMI3HDtJeFY0KYCSBCj9E0ze/367ou95dImmytGXNIxevJMKm5uvhr9zZ8fk2V9EASkcFkmBxLmsMxYzhuDEaT4ZHkxz3Dl3tHL3QNfxKODsYMZtOna5pjKK0pnjWM/PyaqoBvvFoSBh+91Nc3mqDxywacCaqzZo1t+8rElDRllrDQdZ3gm8kAEGFGcHtE5KTN8oDIhdJEJnORJh7duOgPty9bWOZ3F/FpQhcU8PnKA7oT6vjcbVVEZDL3DSfOd4/8sjPyq2tDH3WPhIcTIwmTiDTBQhCbtLqm5KHbF5LLSStft90cfePDG4ZJmiA7n1iaPHsrN+uVdOSOX3IzMWgJvAIi9BjTNOPxuGmamqYJEj5NIybSnOGoFWzw6+K//taSr/xWfUWxzx1JpwnrQse8T1Rd5v9sadFnly8YjBmdfdG2m9F//Th85upg+83RpEm6oO1rqmvL/e7woHz9jx/euNIX1TW5Ksba9yK1DpWc4SgJ6xkY1vbePs2KoxiGIY0h8BaI0GOi0Wg4HJavNY1KA7qw90+TL5g46BPf+lzTf/p0nU8TJlMsaY4mzIRhTbx0IXy68OuaTxdFurRLKX+JI6rygL5ucdnautLta6pG4sapjsi7H4Wv9EV/Z2ONXx+jYcPkn13u//vT3Zrm5GyQncVLzpK1sat4UssCSvy64xbFWDQTQIQeE41Gr127Zpqmruu6EOVBXbM8H5a3QxO08zP1j2+q1TVxuXf0vUt9H3WP9AzGRxKmabIQ5Ne1YJG2oNi3sLSoNuRfWhlsrAguqQyW+sdECBxb59cpUFK0fU311lWVfcOJRfbybufIy72jf3nsykAsqQmSzhzhLJQhotSSVivg7ywoYCJNUHlQ14UgInlS0KHnzFmEqnIfp6pf4Sxl+qaZ2aeJxaGArgnDZLKN0pbmBb//mXoi8dqp7pePd3ZFYibTxIqkN0cIKtK14iJtaWVwTW3JluaKdYvLFpYVlfl1uQLOvYjUr2s19kDUqkQIZn6z9UZb74guyEjt6uTM+CwXDJGdcGzJ0FKpronFoYBPE0II0zT/+I//+C/+4i86OztneSm8WpIxTVVzvTGwx0zh43ZgaJqoC/kDPm0kYUofjS7oq1uW1Jb73/iwZ+/httG4KR8GI8YkEzkZRkREcYPjhhG+OnT6yuDfn+6pCfk3LinburJyc2No+cJiK77uMn3uxavyxVfuqf/s8orjl/uPX+6/dGNkKGbouszmtqxiSo8TBpx+XdSF/PKNZDLZ2toaiUQyfhFvMSBCjxk3f6sLBUr9+nDcICKTeeOS8k2Noa5I7OV/6xyJm7om7Pvfeb4nETlpFlYQkFnoQmg+IqbuSPxwJHz0Yl9tuf9zt1XvWFd9++LSgE8TNN6j4/RhQbHv7mWhTzWUP7G57nzX8Jutvb/4ZKBnMM6pL+3Uo6CEs36biInKAr66UMCK9cfj77///tDQUHavaOEDEWYERwZLKgJLKgLdg3EhSBdi+21VQZ/2xofh39wY1TW3c8Rab2anFzqOE2eRtgzkWbO3hMlX+mI/PNH5o5PXH1xb/QdblqyrK3WaHvdC4vdp9QsC9QsCv726sisSP/Gb/rNXhy7dGGm7OXpjKGGYpnScyqLWY9PY6r88l87Ozo6ODtOc1YZuYPZAhBnBMUcLgr7baks/+GRATu1W15TEDfNc17B13BiZsD0TTHkqXftoM41deCOni/Ekn79u1TbOH+MkT4yzjZoQ9QsCv3tnzZfuWNQ/krgWiR2/1H/0Yt+5ruHRhKlrQrOjF4bJt9WWLghaeUxnzpyJRqMZvnK3IhBhRnBufSFo28rKH528TkTlQd+icn/cMG8Oxe2ghZVR4ZgtK4An7Cd5spXlbu0Ck9otkZnIZFpUWvQnj66+fXGZTBec0VvgHrIGfKI2FKgp93+qIfT01qUf9wwfvhB+v23gQvfwYNRgIk2jbSsrNU0wcyKROHLkSKav260JRJgpnDXQ6xeXLg4FrkdiPk0UacKniZKALo8g+x+2lm1aCYYyLm8NSu2nUzjYM0WqLS/a/YVmJ9nPUeBwzCgNWEvM3P2ZdNIo/6oJWltXtrqm9IlNdWevDR2/3P/2r3s1QU7l4XD43LlzmbtctzIQYWYRQlSWFm1bVfnaqe6EYcYNLinS76gve6u110xt85QKmFvWzDaLThoF28/ZJTvlYllV8I8eXnl3Y4hc9s1kOnax73vvtq+qKfntVVWbG8trygPOOtKJ0Qv52jGhmqBFZUWfW125bWXF0/c1XB+ILSqzNrY4efJke3t7Fq7YLYiyZ9Z7dXwaZOGUxy03e/ej8HNvXGSmP/+927auqLjcO/pfXv31tYG4bifbp3ILZQlbInac35VmT8Jg89ONC77xQOPdTQvcjQohfn196A//8eKF7mFmCvi0lTXFdzcueHBt1R315aUB3e0yHdd5551xx4xfN+dRkm4an3KmA8KZvoGnaxoiTJtZngIzh0cSf/iPF49d6vvvDyx76t4GQfTqya7vHm6LGXKpdCpUx86eFVZhS4JEMqWBFgR9j2xc9AdbGmrKizRXB0yTP74x8j8OXTpzdUgTrtJEpX59xaKSL96+8N6VFfWhwLhk34khjWlOLUOXaMbjpyniFRBh+senQfZFKIR451zvrh+f37S0/NUn7ygp0kbi5t/8/OoPT1wdihu6EClrY2/8Mm7vpqRhBnzafSsqHt9Ud++KCr9Pc1fOzGc6B/f+tP1056CuuUtaSYcyu39JReCzyyu+sK5645LyqpKicbbOnXIx1SLyDF2iGY+fpohXQITpH58GSkQ4Ejd27m89fWXw5cfXfn5NlXznXz/u++vjnZdvjCSsfWicH5Zl1IiEEGUB/beaF3xp/aLNy0JVJVbAwNFGwjBPXxnc8+blS73y8aN23N21YJXJ3uKXqTSgr1pU/MjGmvtWVNSWB/w+MU+lzf8SzXj8NEW8AiJM//g0yOYpu4d5hy+EW/7pYmNl8E9/97blC4vln/pHkz9vG3jvUt/lG6O9w/HRhMlMfl0U+7XqUn9zdfGGJWUbl5SvqS1xz82cDgzFjB+f6vqbE1d7BhO6JuxpoxP6Jys9yQpvkHxtmmwyLw4FHlxb/cDqyjsbysuDvqkuznyuPEQ4q6YhwrSZ/SlIOxOJJv/XT9sO/rL7S3cs+p//bnkomHJNjybMgdHkYCwZTzIT6RoFfVqp31ce1Ev8unva5jRtmtwejv7Nz6/+w5mehGHtRmEHLwSNGU9abwu5Is4e8rJJQlBFse+upaGH71i4dWVlqWtduCfmESKcVdMQYdrMyRLKX7sGYjv/7tcfdw//+/ULv7W9aVlVUBs7K5vq1nfXY5jc2R/96fnwD09c7R2K+3TNvYOwtWehlCKR/QQ0IjseYv9LZC+WM0w2mZdXFz+yseaL6xc2Vxc7ncnCJZrN8dMU8QqIMP3j00DJnNB5/59+dePbP/nNSNy4s6H8a59teOC2SsfJOS4e4G7IEeHN4cTb53r/z5nuC10jcYMdL4xwtlR09tW2Ngy21p3K/+XEUNiBSWewKgQlDTMU9P3Jo6sfWF3plZsUIpxV05k+tykb9u4cMs08b0Sfz/eVr3xl3759FRUVQohY0tz//659/0hHwmCfLraurHj4jpoN9WVVpb5Sf2pTGec6mEzDcaN3KNF+c/RfPrp57GJ/z2DcXmxj/bC8OuzsYWinzFtRSHtHCyv0MT4SKCOQRZr233576e9/pj5YpBFRX19fS0vLK6+84n5KdhbuyKnwqolMf/unccpYMZNxksnk66+/fs899zz55JPM7NfFf7yr7mLP6Otnug2T3r0QPvGbgeXVxSsWFd++uKym3F9R7PP7NMPkWMLsG018Eo629Y5+1DNyfSA2HDc0TWia8xBBa78MS1Mko/6Oe1XY37G2ZK3sCCK5txPZTlhm0+Qvblz4xKa6gM8q88Ybb7z++ut4Tn0WgCWcGU9GwnV1de+8887GjRuJiJl7BhN7f9r2zvmbJtujQvlsXSFlZJkyk9k0rVmesDvjHiiytahbmjzrD675oL2BmqsO14SVnCSph25fuPvB5pryIlnzhx9+uGPHjq6urnFnAUs4I2mcMjY2zxJdXV0tLS1tbW1EJISoDflbHmzasbZahtGFJjQhN6MRJoukySaTIffE0ISmCY1kRF/O34QdC2TherQZWY/YdnKC7e2cSKZIpZw2qcEsk2nyQ7cvbPl8k1QgEbW1tbW0tExUIMgQEGH2OHLkSEtLy82bN+WX5eIFgd1faP7dO2uKdI2YWThZvJa5sz0qRM42MPZDmmzTSSzkceT4WZiczQyJrBkj2wNX+a+9JJy4SBOP3lmz+8HmupBfthsOh1taWpC1lE0wHJ0Zb5eS7Nq16zvf+U5tbS0RMfNg1Pjxqa6//lnnYMzQLD+l9ehAdvLrmZ1OWCNN6yEWriGma09tSq18c+aEY+INzGwylQf0p+5reGJTXajYJ5003d3de/bs+cEPfjBV5zEcnRF4RzOCtyIMBoM7d+7cu3dvdXW1fCeaMN8+1/vXP+v8Te+obEoIImem52x4YQ0n7TeFvS5GRv7kn6yDhBXvIMd56jz8k4iImZYvLH7qvoaH1i2UvlBmDofDu3fv3r9//zTp8xDhjECEGSETiyofe+yxffv2NTc3O+d7fSD24nudh8/f7BtNaHLW51Ke/VhrebD9Jtm+USJnZmilRVkhek4dYyUcckWx7wtrF359W8PiUMAJVMh54MGDB6fvNkQ4I9kQoaprMdd60iDTTU9VvxOjH4wmT7QN/O8Tnac6BjUhdDlhl4/wTD3l1xp22r4ZR37WcyWcWaAc2zquVMNkZt7UGPrqliVbmhfIxaKy6Q8//FDOA+PxuLeXIgtLL+Ll2tEAAAuYSURBVKYiB7/NpwIizF7Tk64pJVfcXL4zmjCPXux7/ZfdZzoHB2MGsx20EOye61nDS2n37D1DU7/ZjZlMQlAooN/ZUP4fPlV7/6rK4iLNabGvr++NN954/vnnr127lolLARHOBogwe01PYwkn1nlzOH76yuCxi/1HL4a7InHDZJkk4cr4tR6nRGOkZ41VTSbDZF2jxaHAtpWV21ZVbmosry71u2VPRF//+tcPHDjgPDxjxq5OBUQ4HyDC7DU9ff2T/jVucN9wovX68LFLfR91D1/tjw3FknGDDZOZyDRT8pMxRF0Tfl2UBXxLKgK31ZZuW1m5fnFpZWmRXxfj7K3sf1FR0aRrYiDCbAIRZq/p2dfPE3KXmGkgmrzaH+uKxLoi8euRWCRqjMSsB1n7NK0koIeC+uJQoC7krwsFllQEFgR9QozpJE9IjMgXb0caQITq60mDXBDhuOHixIaYmZmSJhvWijYZBxSaRroQPm2STokJ+YHOC4gwF8CKmdzCXpKWej3xftU0UaSLoE8r8WtlAV9ZwFca0IuL9CJdaNqYIslksqen5yc/+cksDSBQArIocpSpdOK2YMzsHmEKIWKxWDKZjMfjHR0dZ8+ePXr0aGtra3t7e1dX16R6BrlA3iT1ZgGvhpcZGpsFg8HGxsYtW7b87d/+LU2Y4E2c72WhSzPW4yGqPp259kflihmIcMZ65n/Ha5pWVlbW39/vFHTmkOSaT2azS9PX4yEFLEIMR/MJ0zQjkYj745/qNcgj4JgBQDEQIQCKgQgBUAxECIBiIEIAFDNn7+hcXXBeuewULk/LNaa5FKpW3qmqJw1yMGYGSwiAYiBCABQDEQKgGIgQAMVAhAAoBiIEQDEQIQCKyfjmv5mO/KQRccqFbSwyhFdXO99DqdOQgzl0sIQAKAYiBEAxECEAioEIAVAMRAiAYiBCABQDEQKgGM+2wfeKPNqEb64oTLpTuJ/fnOrPAjkYJYYlBEAxECEAioEIAVAMRAiAYiBCABQDEQKgGIgQAMVkPJ8wB1H1bOcczDPMtYece3iJcm1L1WmAJQRAMRAhAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKGbODwmVKEzKnJG0A76ZDuJnOtKdRlVzJY+WdnjV1Rx9SGguK5ByvnsAjGPOIsQtDoC3FOacEN8UII8oTBECkEdAhAAoBiIEQDEQIQCKSTNOOBXZjCPlnfclC5mvXoU6M318Fsij3aK9tIRZPo08ChwDMA2eiRCSACA98ntOCOWDAiC/RQhAAQARAqAYiBAAxUCEACjG4zjhpMw/WOStA0bVc1HzKLCpqqtppEpmOh5YCJv/5tGdB4ASMBwFQDEQIQCKgQgBUAxECIBiIEIAFAMRAqCYbMQJ8wVV0ZS5RsAUBtNyLSg3TRNzvXpz7aqHsWtYQgAUAxECoBiIEADFQIQAKAYiBEAxECEAioEIAVDMrRgnzJd4YBY288x0Ezm4+WeuPW2SYAkBUA5ECIBiIEIAFAMRAqCYjIsQm2QDMD3ZsITz1CFkDAqbLIUoICQApuJWjBOqepieV/Wn8Y2Wa3mGU5FGqqRXFMjzCQEAaQARAqCY/BYhtvcGBYBnIoQeAEiP/LaEABQAXoowy8YQthcUBh6HKCAMAObKrRgn9AqvIkse7pCZa1+CXqVQToOqPEDkEwJQOECEACimMEWIpaogjyhMEQKQR8xZhLlvZHK/hwC4SccS5vJdnst9A2BS0gxRyHs9pxzikB/IUwTuXQDUAscMAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKAYiBEAxECEAioEIAVAMRAiAYiBCABQDEQKgGIgQAMVAhAAoBiIEQDEQIQCKgQgBUAxECIBiIEIAFAMRAqAYiBAAxUCEACgGIgRAMRAhAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKAYiBEAxECEAioEIAVAMRAiAYiBCABQDEQKgGIhwEpqbm9euXau6F+BWASIEQDEQIQCKgQhT3Lhx49vf/vamTZs6OjouXLhQWVm5cePGp5566tSpU9OUevvtt5944olly5YVFxdXV1d/5jOf+e53vzs8PDx9W9kspbwDHna7MGHAzMyHDh2qqKiY9BJpmnbu3LmJRcLh8IMPPjhpkeXLl7e2tk7aUDZLKe+Ah90uYCBCZuYjR474fD4iWrdu3cGDBxsaGtasWdPf33/69OkXXnhhzZo1J0+eHFdkaGjozjvvlPfTk08+2draGo1G29vbn3/+eVlVfX39tWvXFJaalDztdmEDEXIymVy+fDkRNTY2RiIRZm5qalqzZo37gJGRkXGlnn32WXl7Pffcc+P+tH//fvmnnTt3Kiw1KXna7cIGIuTDhw/LG2Lv3r3ynXEinEg4HA4Gg0TU1NSUTCYnHrBjxw4i0jSts7NTSalC6nbBA8cMnTlzRr6Q9nA2HDlyJBqNEtFjjz2m6/rEA3bt2kVEpmkePHhQSalC6nbBAxGSvFeIqKenZ5ZFLl26JF+sXr160gPuvvtu+eLEiRNKShVStwseiDBlAGf/lTwyMjL9ATU1NfJFa2urklKTkqfdLnggQtqxY4ecvRw/fvyb3/zmbIo4N5DzfT+O/v5++eLatWtKShVStwsf1ZPSnGDv3r3OBbn//vsXLlw4vWPm9OnT8uCpDnvllVfkAZqmKSlVSN0ueCBCiz179mhaalxQV1fX0dExzfGbN2+WR77wwgvj/tTR0VFXV+dU5fYNZrNUIXW7sIEIU7z33nsbNmxw7gy/3//MM8/09/dPevAHH3wgB7FE9PTTT7e2tsbj8d7e3v3799fX1weDwbKyMiIqKSlRVaqQul3YQITjefXVV+XNIamvrz969OikR77zzjuTrnTz+/0/+tGPGhoapEVVWKqQul3AQIST0NTUVFVVVV9f79wxhw8fnvTInp6e3bt3b9iwoaysrKSkZOXKlbt27ZILTUOhEBHdddddaksVUrcLFYhwEuSKmXA4vH37dqnDmpqaoaGh2dfQ29srCz755JO5WUp5Bzzsdr6DEMWUVFZWHjp0aN26dUTU09Nz4MCB2Zc9e/asfHHXXXflZinlHfCw2/kORDgdxcXF3/rWt+TrkydPzr7goUOHiEjTtEceeSQ3SynvgIfdzntUm+JcxL2A21lUtWvXrlkWHxoakv73rVu3zr7RbJZS3gEPu10AQIQ8MU3JLcJXX31VivD73//+LCtsaWmRRY4cOTL7bmSzlPIOeNjtAgAi5Jdffvm5555zS9ER4cjIiExLDQaD42L3U/lpXnnlFRn0f/zxxyf+NZulHn30USLy+/3uUGfud/sWBCK0Ekzr6+v37Nlz4sSJ3t7epqam5cuXHzhwwInd/9mf/dm4Um+++ebmzZtfeeWV9vZ2GYN+99135X1PRPfee+9EA5vlUnK8t3379vzq9i0IRMjMvGfPHrnhwkRCodDLL788scjRo0enmmZ/9atflRn6Cks5y6ZffPHFPOr2rQlEaPHxxx8/++yz69evlxFkv9+/ffv2733vez09PVMVOX78+Je//OWGhga/319VVbVhw4Znn3124m40Sko5+0dMzFvP5W7fmghmnurr6palubk5GAyeP39edUfS56mnnnr55Zc3b978i1/8QnVfwAwgTliYyMgKQnB5AURYgAwODsp0dYgwL5jcG3GL09bWproL8+LEiROmaa5cufL2229X3RcwM5gTAqAYDEcBUAxECIBiIEIAFAMRAqAYiBAAxUCEACgGIgRAMRAhAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKAYiBEAxECEAioEIAVAMRAiAYiBCABQDEQKgGIgQAMVAhAAoBiIEQDEQIQCKgQgBUAxECIBiIEIAFAMRAqAYiBAAxUCEACgGIgRAMRAhAIqBCAFQDEQIgGIgQgAUAxECoBiIEADFQIQAKOb/A5eguqQjdDAFAAAAAElFTkSuQmCC"
          />
        </p>
      </div>
      <br />
      <h3>
        Casino status:
        <span class="badge badge-success">{{ status }}</span>
      </h3>
      <br />
      <h4>Pending user</h4>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">User</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(p, i) in pendings">
            <th scope="col">{{ i }}</th>
            <th scope="col">{{ p }}</th>
          </tr>
        </tbody>
      </table>
      <br />
      <h4>Formal player</h4>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">User</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(p, i) in players">
            <th scope="col">{{ i }}</th>
            <th scope="col">{{ p }}</th>
          </tr>
        </tbody>
      </table>
      <br />
      <h4>Winners</h4>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">User</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(w, i) in winners">
            <th scope="col">{{ i }}</th>
            <th scope="col">{{ w }}</th>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import NavBar from "./NavBar.vue";
import { api } from "../config";

export default {
  name: "Index",

  created() {
    this.getStatus();
  },

  methods: {
    getStatus: function() {
      fetch(api + "/service/status", {
        method: "GET",
        credentials: "include"
      })
        .then(resp => resp.json())
        .then(respJSON => {
          var status = respJSON["data"]["status"];
          if (status) this.status = "running";
          else this.status = "stopped";
        });

      fetch(api + "/service/player-status", {
        method: "GET",
        credentials: "include"
      })
        .then(resp => resp.json())
        .then(respJSON => {
          this.pendings = respJSON["data"]["pendings"];
          this.players = respJSON["data"]["players"];
          this.winners = respJSON["data"]["winners"];
        });
    },

    change: function() {
      this.show = !this.show
    }
  },

  data() {
    return {
      status: "stopped",
      pendings: [],
      players: [],
      winners: [],
      show: false
    };
  }
};
</script>

<style>
</style>
