<template>
  <div id="register">
    <NavBar></NavBar>
    <br />
    <router-view></router-view>
    <div class="container col-md-6">
      <form>
        <div class="form-group">
          <label for="uname">Username:</label>
          <input v-model="uname" type="input" class="form-control" id="uname" />
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input v-model="pwd" @change="verifyPwd" type="password" class="form-control" id="pwd" />
        </div>
        <div v-if="!lt8" class="alert alert-danger" role="alert">length(password) must >= 8</div>
        <div class="form-group">
          <label for="hash-token">sha1(v)[:6] == {{ hash }}, v = ?</label>
          <input v-model="hashToken" type="input" class="form-control" id="hash-token" />
        </div>
        <button type="submit" @click="register" class="btn btn-primary">Register</button>
      </form>
    </div>
  </div>
</template>

<script>
import NavBar from "./NavBar.vue";
import { auth } from "../config";

export default {
  name: "Register",

  created() {
    this.getHash();
  },

  methods: {
    getHash: function() {
      var url = auth + "/hash";
      fetch(url, {
        method: "GET",
        credentials: "include"
      })
        .then(resp => resp.json())
        .then(respJSON => {
          this.hash = respJSON["data"];
        });
    },

    verifyPwd: function() {
      if (pwd.value.length > 0 && pwd.value.length < 8) this.lt8 = false;
      else this.lt8 = true;
    },

    register: function() {
      var url = auth + "/register";
      var data = {
        uname: this.uname,
        pwd: this.pwd,
        raw_hash: this.hashToken
      };
      fetch(url, {
        method: "POST",
        credentials: "include",
        body: JSON.stringify(data)
      })
        .then(resp => resp.json())
        .then(respJSON => {
          if (respJSON["status"] == 0) {
            alert("register success");
            location.href = "#/login";
          } else {
            alert(respJSON["msg"]);
            location.reload();
          }
        });
    }
  },

  data() {
    return {
      uname: "",
      pwd: "",
      lt8: true,
      hash: "",
      hashToken: ""
    };
  }
};
</script>

<style>
</style>
