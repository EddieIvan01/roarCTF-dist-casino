<template>
  <div id="index">
    <NavBar></NavBar>
    <br />
    <router-view></router-view>
    <div class="container col-md-6">
      <h3>Uname: {{ uname }}</h3>
      <h3>Balance: {{ total_balance }}</h3>
      <h4>&#128681; {{ flag }}</h4>
      <br />
      <button @click="act('beg')" type="button" class="btn btn-info">BEG</button>
      <button @click="act('join')" type="button" class="btn btn-info">JOIN</button>
      <button @click="act('reset')" type="button" class="btn btn-info">RESET</button>
    </div>
  </div>
</template>

<script>
import NavBar from "./NavBar.vue";
import { api } from "../config";

export default {
  name: "Profile",

  created() {
    this.auth();
    this.getInfo();
  },

  methods: {
    auth: function() {
      if (window.sessionStorage.pwd) return;
      var pwd = prompt(
        "to access this sensitive page, you need to enter your password"
      );
      window.sessionStorage.pwd = pwd;
    },

    getInfo: function() {
      var url = api + "/u/info";
      fetch(url, {
        method: "POST",
        credentials: "include",
        body: JSON.stringify({
          pwd: window.sessionStorage.pwd
        })
      })
        .then(resp => resp.json())
        .then(respJSON => {
          this.flag = respJSON["msg"];
          this.uname = respJSON["data"]["uname"];
          this.total_balance = respJSON["data"]["total_balance"];
        });
    },

    act: function(action) {
      fetch(api + "/u/" + action, {
        method: "POST",
        credentials: "include",
        body: JSON.stringify({
          pwd: window.sessionStorage.pwd
        })
      }).then(function() {
          location.reload();
      });
    }
  },

  data() {
    return {
      flag: "",
      uname: "",
      total_balance: ""
    };
  }
};
</script>

<style>
</style>
