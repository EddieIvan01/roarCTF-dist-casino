var auth = 'http://127.0.0.1:9000/auth';
var api = 'http://127.0.0.1:5001/api';
export { auth, api };
// my source code backup
// /backup-for-debug.7z